#include<stdio.h>

int main()
{
    float a;
    scanf("%f",&a);
    if (a==-12)
    {
        printf("%.4f is negative",a);
    }
    else
    {
        printf("%.4f is zero",a);
    }
    return 0;
}